ITAE demo v2.0 [changes: script builder & manual prompts]
For nwjs version, Animation files can be found in user-folder/ITAE

Author: Mehdi EL
Youtube: youtube.com/@IGA777
Patreon: patreon.com/cgem